<?php

$var=1;
$DELETE=$_POST["image"];
     $data = file("../images/images.txt");

     $out = array();

     foreach($data as $line) {
         if($var != $DELETE) {
             $out[] = $line;
         }
$var=$var +1;     
}

     $fp = fopen("../images/images.txt", "w+");
     flock($fp, LOCK_EX);
     foreach($out as $line) {
         fwrite($fp, $line);
     }
     flock($fp, LOCK_UN);
     fclose($fp);
header("Location: http://www.projectyogisha.com/green/"); /* Redirect browser */
exit(); 
?>