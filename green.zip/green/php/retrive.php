<?php 
//$button = $_GET['button'];
 $image_list = array();
 $handle = fopen("../images/images.txt", "r");
  if ($handle) {
    while (($line = fgets($handle)) !== false) {
        $image_list[] = $line;
    }

    fclose($handle);
} else {
    print ("error");
}  
// Finally depending on the button value, JSON encode our winetable and print it
  print json_encode($image_list);
 
?>