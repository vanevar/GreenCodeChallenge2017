<?php
$image=$_POST["image"];
$myFile = "../images/images.txt";
$fh = fopen($myFile, 'a') or die("can't open file");
fwrite($fh, "\n");
fwrite($fh, $image);
fclose($fh);
header("Location: http://www.projectyogisha.com/green/"); /* Redirect browser */
exit();
?>