function retrive(){ 

    $.ajax({ // ajax call starts
      url: 'php/retrive.php', // JQuery loads serverside.php
      //data: 'button=' + $(this).val(), // Send value of the clicked button
      dataType: 'json', // Choosing a JSON datatype
    })
    .done(function(data) { // Variable data contains the data we get from serverside
      $('.image_container').html(''); // Clear #wines div
	      for (var i in data) {
         
		 $('.image_container').append("<div class=\"item\"><img src=\""+data[i]+"\"  ></div>");
		$('.carousel-indicators').append("<li data-target=\"#myCarousel\" data-slide-to=\""+i+"\" ></li>");		
		
		}
      $('.carousel-indicators li').eq(0).addClass('active');	      
	  $('.item').first().addClass('active');
	  
    
    });
    return false; // keeps the page from not refreshing 
}
